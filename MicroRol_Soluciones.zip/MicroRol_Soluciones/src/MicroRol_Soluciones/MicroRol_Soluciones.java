package MicroRol_Soluciones;

import java.util.ArrayList;
import java.util.Scanner;

public class MicroRol_Soluciones {
    static ArrayList<Producto> inventario = new ArrayList<>();
    static ArrayList<Venta> registroVentas = new ArrayList<>();

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int opcionMenu;

        do {
            // Mostrar menú principal
            System.out.println("\nMenu Principal");
            System.out.println("--------------------------");
            System.out.println("1. Registro de productos");
            System.out.println("2. Registro de Venta y Facturacion");
            System.out.println("3. Mostrar Inventario");
            System.out.println("4. Mostrar Registro de Ventas");
            System.out.println("5. Salir");
            System.out.println("--------------------------");
            System.out.print("Ingrese su opcion: ");
            opcionMenu = scanner.nextInt();

            switch (opcionMenu) {
                case 1:
                    registroProductos(scanner);
                    break;
                case 2:
                    registroVenta(scanner);
                    break;
                case 3:
                    mostrarInventario();
                    break;
                case 4:
                    mostrarRegistroVentas();
                    break;
                case 5:
                    System.out.println("\nGracias por utilizar MicroRol_Soluciones. ¡Hasta luego!");
                    break;
                default:
                    System.out.println("\nOpción inválida. Por favor, ingrese una opción válida.");
            }
        } while (opcionMenu != 5);
    }

    public static void registroProductos(Scanner scanner) {
        int opcionLinea;

        do {
            // Mostrar menú de líneas
            System.out.println("\nRegistro de productos");
            System.out.println("--------------------------");
            System.out.println("Escoger Línea");
            System.out.println("1. Blanca");
            System.out.println("2. Electro");
            System.out.println("3. Marron");
            System.out.println("4. Volver al menú principal");
            System.out.println("--------------------------");
            System.out.print("Ingrese su opcion: ");
            opcionLinea = scanner.nextInt();

            switch (opcionLinea) {
                case 1:
                case 2:
                case 3:
                    Producto producto = llenarFormulario(scanner);
                    if (producto != null) {
                        inventario.add(producto);
                    }
                    break;
                case 4:
                    System.out.println("\nVolviendo al menú principal...");
                    break;
                default:
                    System.out.println("\nOpción inválida. Por favor, ingrese una opción válida.");
            }
        } while (opcionLinea != 4);
    }

    public static Producto llenarFormulario(Scanner scanner) {
        // Pedir datos y crear objeto Producto
        System.out.println("\nLlenar Formulario:");
        System.out.print("Marca: ");
        String marca = scanner.next();
        System.out.print("Modelo: ");
        String modelo = scanner.next();
        System.out.print("Producto: ");
        scanner.nextLine(); // Consumir el salto de línea pendiente antes de leer el nombre del producto
        String nombreProducto = scanner.nextLine();
        System.out.print("Fecha: ");
        String fecha = scanner.next();
        
        // Solicitar el precio de venta hasta que sea un valor entero válido
        int precioVenta = 0;
        boolean precioValido;
        do {
            System.out.print("Precio de Venta (entero): ");
            if (scanner.hasNextInt()) {
                precioVenta = scanner.nextInt();
                precioValido = true;
            } else {
                System.out.println("Error: El precio debe ser un valor entero.");
                scanner.next(); // Consumir entrada inválida
                precioValido = false;
            }
        } while (!precioValido);

        // Validar datos
        if (marca.isEmpty() || modelo.isEmpty() || nombreProducto.isEmpty() || fecha.isEmpty()) {
            System.out.println("Error: Todos los campos son obligatorios.");
            return null;
        }

        return new Producto(marca, modelo, nombreProducto, fecha, precioVenta);
    }

    public static void registroVenta(Scanner scanner) {
        int opcionTipoVenta;

        do {
            // Mostrar menú de tipos de venta
            System.out.println("\nRegistro de Venta y Facturacion");
            System.out.println("--------------------------");
            System.out.println("1. Venta crédito");
            System.out.println("2. Venta Débito");
            System.out.println("3. Volver al menú principal");
            System.out.println("--------------------------");
            System.out.print("Ingrese su opcion: ");
            opcionTipoVenta = scanner.nextInt();

            switch (opcionTipoVenta) {
                case 1:
                case 2:
                    Producto producto = llenarFormulario(scanner);
                    if (producto != null) {
                        registroVentas.add(new Venta(opcionTipoVenta == 1 ? "Credito" : "Debito", producto));
                    }
                    break;
                case 3:
                    System.out.println("\nVolviendo al menú principal...");
                    break;
                default:
                    System.out.println("\nOpción inválida. Por favor, ingrese una opción válida.");
            }
        } while (opcionTipoVenta != 3);
    }

    public static void mostrarInventario() {
        System.out.println("\nInventario:");
        System.out.println("-----------------------------------------------------");
        if (inventario.isEmpty()) {
            System.out.println("El inventario está vacío.");
        } else {
            System.out.printf("| %-10s | %-10s | %-20s | %-10s | %-15s |\n", "Marca", "Modelo", "Producto", "Fecha", "Precio de Venta");
            System.out.println("|------------|------------|----------------------|------------|-----------------|");
            for (Producto producto : inventario) {
                System.out.printf("| %-10s | %-10s | %-20s | %-10s | %-15d |\n",
                        producto.getMarca(), producto.getModelo(), producto.getNombreProducto(),
                        producto.getFecha(), producto.getPrecioVenta());
            }
        }
        System.out.println("-----------------------------------------------------");
    }


    public static void mostrarRegistroVentas() {
        System.out.println("\nRegistro de Ventas:");
        System.out.println("--------------------------");
        if (registroVentas.isEmpty()) {
            System.out.println("No hay ventas registradas.");
        } else {
            for (Venta venta : registroVentas) {
                System.out.println(venta);
            }
        }
    }
}

