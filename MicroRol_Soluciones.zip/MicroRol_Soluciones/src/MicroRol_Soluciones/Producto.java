package MicroRol_Soluciones;

public class Producto {
    private String marca;
    private String modelo;
    private String nombreProducto;
    private String fecha;
    private double precioVenta;

    public Producto(String marca, String modelo, String nombreProducto, String fecha, double precioVenta) {
        this.marca = marca;
        this.modelo = modelo;
        this.nombreProducto = nombreProducto;
        this.fecha = fecha;
        this.precioVenta = precioVenta;
    }

    @Override
    public String toString() {
        return "Producto{" +
                "marca='" + marca + '\'' +
                ", modelo='" + modelo + '\'' +
                ", nombreProducto='" + nombreProducto + '\'' +
                ", fecha='" + fecha + '\'' +
                ", precioVenta=" + precioVenta +
                '}';
    }

	public Object getMarca() {
		// TODO Auto-generated method stub
		return null;
	}

	public Object getModelo() {
		// TODO Auto-generated method stub
		return null;
	}

	public Object getNombreProducto() {
		// TODO Auto-generated method stub
		return null;
	}

	public Object getFecha() {
		// TODO Auto-generated method stub
		return null;
	}

	public Object getPrecioVenta() {
		// TODO Auto-generated method stub
		return null;
	}
}
