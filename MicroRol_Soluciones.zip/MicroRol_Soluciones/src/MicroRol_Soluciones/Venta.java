package MicroRol_Soluciones;

public class Venta {
    private String tipoVenta;
    private Producto producto;

    public Venta(String tipoVenta, Producto producto) {
        this.tipoVenta = tipoVenta;
        this.producto = producto;
    }

    @Override
    public String toString() {
        return "Venta{" +
                "tipoVenta='" + tipoVenta + '\'' +
                ", producto=" + producto +
                '}';
    }
}
